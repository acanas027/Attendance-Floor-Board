"""Floor Board demo entry point.

Run:  streamlit run app.py
In the Schedule Board app, the same window is added with:
    from floor_board import page
    page()
"""

import streamlit as st

from floor_board import page

st.set_page_config(page_title="Floor Board", page_icon=":material/groups:", layout="wide", initial_sidebar_state="collapsed")
page()
