"""Sample data for the Floor Board demo.

Made-up names only. When the app goes live, this file is replaced by the
roster and area list read from the shared backend (Google Sheets).
"""

ROLES = {
    "Operator": "#60A5FA",
    "Assistant": "#FBBF24",
    "Palletizer": "#2DD4BF",
    "Kit line": "#C4B5FD",
}

# id, name, short label, standard crew size (None = no standard)
AREAS = [
    *[{"id": f"L{n}", "name": f"Line {n}", "short": f"L{n}", "std": 2} for n in range(1, 19)],
    {"id": "KIT", "name": "Kit Line", "short": "Kit", "std": 5},
    {"id": "PAL", "name": "Palletizing", "short": "Pallet", "std": 6},
    {"id": "BRK", "name": "Break", "short": "Break", "std": None},
]
# A few lines run with an assistant.
for _a in AREAS:
    if _a["id"] in ("L3", "L7", "L10", "L15"):
        _a["std"] = 3

# name, role, usual area
EMPLOYEES = [
    ("Maria R.", "Operator", "L1"), ("Jose L.", "Operator", "L1"),
    ("Ana P.", "Operator", "L2"), ("Luis G.", "Operator", "L2"),
    ("Carmen D.", "Operator", "L3"), ("Pedro S.", "Operator", "L3"), ("Sofia M.", "Assistant", "L3"),
    ("Juan C.", "Operator", "L4"), ("Rosa T.", "Operator", "L4"),
    ("Miguel A.", "Operator", "L5"), ("Elena V.", "Operator", "L5"),
    ("Diego F.", "Operator", "L6"), ("Laura B.", "Operator", "L6"),
    ("Carlos N.", "Operator", "L7"), ("Teresa G.", "Operator", "L7"),
    ("Isabel Q.", "Operator", "L8"), ("Jorge H.", "Operator", "L8"),
    ("Lucia K.", "Operator", "L9"), ("Raul E.", "Operator", "L9"),
    ("Paula W.", "Operator", "L10"), ("Tomas Y.", "Operator", "L10"), ("Hector Z.", "Assistant", "L10"),
    ("Daniel O.", "Operator", "L11"), ("Marta I.", "Operator", "L11"),
    ("Sergio V.", "Operator", "L12"), ("Andrea F.", "Operator", "L12"),
    ("Victor U.", "Operator", "L13"), ("Silvia J.", "Operator", "L13"),
    ("Pablo X.", "Operator", "L14"), ("Teresa M.", "Operator", "L14"),
    ("Ramon G.", "Operator", "L15"), ("Alicia C.", "Operator", "L15"), ("Ruben L.", "Assistant", "L15"),
    ("Gloria P.", "Operator", "L16"), ("Fernando D.", "Operator", "L16"),
    ("Adrian S.", "Operator", "L17"), ("Beatriz N.", "Operator", "L17"),
    ("Hugo R.", "Operator", "L18"), ("Nora T.", "Operator", "L18"),
    ("Irene A.", "Kit line", "KIT"), ("Oscar B.", "Kit line", "KIT"), ("Clara E.", "Kit line", "KIT"),
    ("Felipe G.", "Kit line", "KIT"), ("Ines H.", "Kit line", "KIT"),
    ("Mateo I.", "Palletizer", "PAL"), ("Julia K.", "Palletizer", "PAL"), ("Samuel L.", "Palletizer", "PAL"),
    ("Rocio M.", "Palletizer", "PAL"), ("Ivan N.", "Palletizer", "PAL"), ("Lorena O.", "Palletizer", "PAL"),
    ("Emilio P.", "Assistant", "L7"),
]

SHIFTS = {
    "1st shift": {"start": (6, 0)},
    "2nd shift": {"start": (16, 0)},
}

CHECK_EVERY_MIN = 120
