"""Floor Board screens. `page()` draws the whole window with its four sub-windows."""

from __future__ import annotations

import pandas as pd
import streamlit as st

from . import data, store
from .store import BOX

ROLE_KEY = {"Operator": "op", "Assistant": "as", "Palletizer": "pa", "Kit line": "kt"}
GRID_COLS = 7

CSS = """
<style>
/* chips: one per employee, colored by role */
[class*="st-key-chip-"] button {
  border-radius: 999px; border: 0; min-height: 40px; padding: 2px 14px;
  font-weight: 700; color: #0B1220 !important;
}
[class*="st-key-chip-op-"] button { background: #60A5FA; }
[class*="st-key-chip-as-"] button { background: #FBBF24; }
[class*="st-key-chip-pa-"] button { background: #2DD4BF; }
[class*="st-key-chip-kt-"] button { background: #C4B5FD; }
[class*="st-key-chip-"] button:hover { filter: brightness(1.1); color: #0B1220 !important; }
[class*="st-key-chip-"][class*="-sel-"] button {
  outline: 3px solid #FACC15; outline-offset: 2px; transform: scale(1.05);
}
[class*="st-key-chip-"][class*="-dim-"] button { opacity: .7; }

/* primary buttons: dark text on yellow */
button[kind="primary"] { color: #0B1220 !important; font-weight: 700; }

/* area header buttons */
[class*="st-key-zh-"] button {
  min-height: 44px; border: 0; background: #1B2740; color: #E5ECF6 !important; font-weight: 700;
}
[class*="st-key-zh-short-"] button { color: #FCA5A5 !important; }
[class*="st-key-zh-target-"] button { background: #FACC15; color: #0B1220 !important; }

.fb-zh { display:flex; justify-content:space-between; align-items:center; min-height:44px; padding:0 12px;
  border-radius:10px; background:#1B2740; font-weight:700; font-size:15px; }
.fb-zh span { color:#94A3B8; font-size:14px; }
.fb-zh.short span { color:#FCA5A5; }
.fb-zh.brk { background:#151E30; }

/* area tiles */
[class*="st-key-zone-"] { background: #131C2E; border-radius: 14px; }
[class*="st-key-zone-short-"] { border: 1px solid #F87171 !important; }
[class*="st-key-zone-target-"] { border: 1px solid #FACC15 !important; }
[class*="st-key-zone-brk-"] { border: 1px dashed #475569 !important; background: #0F1626; }
[class*="st-key-boxzone"] { background: #131C2E; border-radius: 14px; }

/* pills */
.fb-pill { display:inline-block; padding:6px 12px; border-radius:12px; background:#131C2E;
  border:1px solid #26344D; font-size:14px; margin-right:6px; }
.fb-pill b { font-weight:700; }
.fb-live { display:inline-block; padding:3px 10px; border-radius:999px; background:#0F2A1E;
  color:#4ADE80; font-size:12px; font-weight:700; letter-spacing:.06em; }
.fb-due { display:inline-block; padding:8px 12px; border-radius:12px; font-weight:600; font-size:14px; }
.fb-hint { padding:10px 14px; border-radius:12px; background:#FACC15; color:#0B1220; font-weight:600; }
.fb-move { display:inline-block; padding:6px 10px; border-radius:10px; background:#1B2740;
  font-size:13px; margin:0 6px 6px 0; }
.fb-move span { color:#94A3B8; margin-right:6px; }
.fb-legend span { display:inline-flex; align-items:center; gap:5px; margin-right:12px; font-size:13px; color:#94A3B8; }
.fb-legend i { width:10px; height:10px; border-radius:50%; display:inline-block; }
</style>
"""


# ---------- shared pieces ----------

def _moves(s: dict) -> int:
    return sum(1 for ev in s["events"] if ev["kind"] in ("move", "late", "left"))


def _chip(s: dict, e: dict, where: str) -> None:
    sel = s["selected"]
    state = "sel" if sel == e["id"] else ("dim" if sel else "n")
    st.button(
        e["name"],
        key=f"chip-{ROLE_KEY[e['role']]}-{state}-{where}-{e['id']}",
        on_click=store.select, args=(s, e["id"]),
        help=f"{e['name']} · {e['role']}",
        disabled=s["ended"],
        width="stretch" if where == "tile" else "content",
    )


def _legend() -> None:
    items = "".join(f'<span><i style="background:{c}"></i>{r}</span>' for r, c in data.ROLES.items())
    st.markdown(f'<div class="fb-legend">{items}</div>', unsafe_allow_html=True)


# ---------- dialogs ----------

@st.dialog("Confirm attendance")
def _attendance_dialog(s: dict) -> None:
    absent = store.crew(s, BOX)
    present = len(s["employees"]) - len(absent)
    st.write(f"**{present} present** (on a line) · **{len(absent)} absent** (still in the box)")
    if absent:
        st.caption("Will be marked absent: " + ", ".join(e["name"] for e in absent))
    st.caption("Line time starts now. Anyone placed later from the box is recorded as late.")
    c1, c2 = st.columns(2)
    if c1.button("Confirm", type="primary", width="stretch"):
        store.confirm_attendance(s)
        st.rerun()
    if c2.button("Go back", width="stretch"):
        st.rerun()


@st.dialog("End shift")
def _end_dialog(s: dict) -> None:
    st.write("This closes everyone's time at " + store.fmt(store.now(s)) + " and locks the board.")
    c1, c2 = st.columns(2)
    if c1.button("End shift", type="primary", width="stretch"):
        store.end_shift(s)
        st.rerun()
    if c2.button("Cancel", width="stretch"):
        st.rerun()


# ---------- sub-window 1: floor lead board ----------

def board(s: dict) -> None:
    on_floor = sum(1 for e in s["employees"] if s["assign"][e["id"]] not in (BOX, "BRK"))
    in_box = len(store.crew(s, BOX))

    top_l, top_r = st.columns([3, 2], vertical_alignment="center")
    with top_l:
        st.markdown(
            f"### Floor Board &nbsp;<span class='fb-live'>LIVE</span>\n"
            f"{s['shift']} · Floor lead: {s['lead']} · {store.fmt(store.now(s))}",
            unsafe_allow_html=True,
        )
    with top_r:
        box_label = "Absent" if s["attendance_confirmed"] else "Not placed"
        st.markdown(
            f"<span class='fb-pill'>On floor <b>{on_floor}</b></span>"
            f"<span class='fb-pill'>{box_label} <b>{in_box}</b></span>"
            f"<span class='fb-pill'>Moves <b>{_moves(s)}</b></span>"
            f"<span class='fb-pill'>Check-ins <b style='color:#FACC15'>{s['checkins']}</b></span>",
            unsafe_allow_html=True,
        )

    # status / action row
    if s["ended"]:
        st.success(f"Shift ended at {store.fmt(s['end_time'])}. See End of shift for the totals.")
    elif not s["attendance_confirmed"]:
        st.info(
            "**Start of shift:** tap a name, then tap the line they're working. "
            "When everyone who's here is placed, confirm attendance. Anyone left in the box is marked absent."
        )
        a, b, c = st.columns([1, 1, 2])
        a.button("Load usual layout", on_click=store.load_usual_layout, args=(s,), width="stretch")
        b.button("Clear board", on_click=store.clear_board, args=(s,), width="stretch")
        present = len(s["employees"]) - in_box
        if c.button(f"Confirm attendance · {present} present · {in_box} absent", type="primary", width="stretch"):
            _attendance_dialog(s)
    else:
        left = store.check_minutes_left(s)
        if left >= 0:
            pill = f"<span class='fb-due' style='background:#2A2111;color:#FBBF24'>Board check due in {left} min</span>"
        else:
            pill = f"<span class='fb-due' style='background:#2A1517;color:#FCA5A5'>Board check overdue by {-left} min</span>"
        a, b = st.columns([3, 1], vertical_alignment="center")
        a.markdown(pill, unsafe_allow_html=True)
        b.button("Board is correct", type="primary", on_click=store.confirm_board, args=(s,), width="stretch")

    # selection hint
    if s["selected"]:
        e = store.emp(s, s["selected"])
        h1, h2 = st.columns([5, 1], vertical_alignment="center")
        h1.markdown(f"<div class='fb-hint'>Moving {e['name']} — tap <b>Move here</b> on the area they're going to.</div>",
                    unsafe_allow_html=True)
        h2.button("Cancel", on_click=store.cancel_selection, args=(s,), width="stretch")
    else:
        _legend()

    # the box
    sel = s["selected"]
    with st.container(border=True, key="boxzone"):
        title = "Absent / off the floor" if s["attendance_confirmed"] else "Not placed yet"
        if sel and s["assign"][sel] is not BOX:
            label = "Move here · left the floor" if s["attendance_confirmed"] else "Move here · back to the box"
            st.button(label, key="zh-target-BOX", on_click=store.move_selected, args=(s, BOX), width="stretch")
        else:
            st.markdown(f"**{title}** · {in_box}")
        with st.container(horizontal=True, wrap=True, gap="small"):
            for e in store.crew(s, BOX):
                _chip(s, e, "box")

    # the areas
    areas = s["areas"]
    for i in range(0, len(areas), GRID_COLS):
        cols = st.columns(GRID_COLS, gap="small")
        for col, a in zip(cols, areas[i:i + GRID_COLS]):
            with col:
                _tile(s, a)

    # latest moves
    moves = [ev for ev in s["events"]][:5]
    if moves:
        html = "".join(f"<span class='fb-move'><span>{store.fmt(ev['t'])}</span>{ev['text']}</span>" for ev in moves)
        st.markdown("**Latest** &nbsp; " + html, unsafe_allow_html=True)


def _tile(s: dict, a: dict) -> None:
    people = store.crew(s, a["id"])
    n = len(people)
    sel = s["selected"]
    is_target = bool(sel) and s["assign"][sel] != a["id"]
    is_short = a["std"] is not None and n < a["std"] and s["attendance_confirmed"]
    if is_target:
        state = "target"
    elif a["id"] == "BRK":
        state = "brk"
    elif is_short:
        state = "short"
    else:
        state = "ok"
    count = str(n) if a["std"] is None else f"{n}/{a['std']}"
    with st.container(border=True, key=f"zone-{state}-{a['id']}"):
        if is_target:
            st.button(f"Move to {a['short']}", key=f"zh-target-{a['id']}", on_click=store.move_selected,
                      args=(s, a["id"]), width="stretch", help=f"Move to {a['name']}")
        else:
            st.markdown(f"<div class='fb-zh {state}'>{a['name']}<span>{count}</span></div>",
                        unsafe_allow_html=True)
        for e in people:
            _chip(s, e, "tile")


# ---------- sub-window 2: supervisor live view ----------

def supervisor(s: dict) -> None:
    st.markdown(f"### Live floor &nbsp;<span class='fb-live'>LIVE</span>", unsafe_allow_html=True)
    st.caption(f"{s['shift']} · as of {store.fmt(store.now(s))} · in the live version this refreshes every few seconds")

    att = s["attendance"]
    on_floor = sum(1 for e in s["employees"] if s["assign"][e["id"]] not in (BOX, "BRK"))
    on_break = len(store.crew(s, "BRK"))
    absent = sum(1 for v in att.values() if v["status"] == "Absent")
    late = sum(1 for v in att.values() if v["status"] == "Late")
    short = store.short_areas(s) if s["attendance_confirmed"] else []

    m = st.columns(5)
    m[0].metric("On the floor", on_floor, help=f"{on_break} on break")
    m[1].metric("Absent", absent if s["attendance_confirmed"] else "—")
    m[2].metric("Late", late if s["attendance_confirmed"] else "—")
    m[3].metric("Areas short", len(short) if s["attendance_confirmed"] else "—")
    m[4].metric("Moves", _moves(s))

    if not s["attendance_confirmed"]:
        st.info("Attendance not confirmed yet. Line time starts when the floor lead confirms.")
    else:
        st.markdown("**Needs attention**")
        left = store.check_minutes_left(s)
        any_alert = False
        if left < 0 and not s["ended"]:
            st.warning(f"Board check overdue by {-left} min ({s['lead']})")
            any_alert = True
        for a, n in short:
            st.error(f"{a['name']}: {n} of {a['std']}")
            any_alert = True
        if not any_alert:
            st.success("All areas staffed and the board is up to date.")

    st.markdown("**Crews**")
    rows = []
    for a in s["areas"]:
        people = store.crew(s, a["id"])
        rows.append({
            "Area": a["name"],
            "Crew": ", ".join(e["name"] for e in people),
            "On crew": len(people),
            "Standard": a["std"],
        })
    st.dataframe(pd.DataFrame(rows), hide_index=True, width="stretch", height=420)

    st.markdown("**Latest moves**")
    if s["events"]:
        st.dataframe(
            pd.DataFrame([{"Time": store.fmt(ev["t"]), "What": ev["text"]} for ev in s["events"][:10]]),
            hide_index=True, width="stretch",
        )
    else:
        st.caption("No moves yet.")


# ---------- sub-window 3: end of shift ----------

def summary(s: dict) -> None:
    st.markdown("### End of shift · time by area")
    if not s["attendance_confirmed"]:
        st.info("Nothing recorded yet. Time starts when attendance is confirmed on the Floor Board.")
        return

    if s["ended"]:
        st.caption(f"{s['shift']} · {store.fmt(s['attendance_time'])} – {store.fmt(s['end_time'])} · built from the board moves")
    else:
        c1, c2 = st.columns([3, 1], vertical_alignment="center")
        c1.caption(f"Shift in progress · totals as of {store.fmt(store.now(s))}")
        if c2.button("End shift", type="primary", width="stretch"):
            _end_dialog(s)

    rows = store.summary_rows(s)
    view = pd.DataFrame(rows)[["Employee", "Role", "Attendance", "Time by area", "Break", "Worked"]]
    st.dataframe(view, hide_index=True, width="stretch", height=460)

    # downloads: one row per employee per area (what scoring uses), attendance, move log
    long_rows = []
    for r in rows:
        for a, mins in r["areas"].items():
            long_rows.append({"Employee": r["Employee"], "Role": r["Role"], "Area": store.area(s, a)["name"],
                              "Minutes": round(mins)})
    att_rows = [{"Employee": r["Employee"], "Role": r["Role"], "Attendance": r["Attendance"]} for r in rows]
    log_rows = [{"Time": store.fmt(ev["t"]), "Event": ev["text"]} for ev in reversed(s["events"])]

    d1, d2, d3 = st.columns(3)
    d1.download_button("Minutes by area (CSV)", pd.DataFrame(long_rows).to_csv(index=False),
                       "minutes_by_area.csv", "text/csv", width="stretch")
    d2.download_button("Attendance (CSV)", pd.DataFrame(att_rows).to_csv(index=False),
                       "attendance.csv", "text/csv", width="stretch")
    d3.download_button("Move log (CSV)", pd.DataFrame(log_rows).to_csv(index=False),
                       "move_log.csv", "text/csv", width="stretch")

    st.markdown("**Move log**")
    st.dataframe(pd.DataFrame(log_rows), hide_index=True, width="stretch")


# ---------- sub-window 4: setup ----------

def setup(s: dict) -> None:
    st.markdown("### Setup")
    locked = s["attendance_confirmed"]

    c1, c2 = st.columns(2)
    s["lead"] = c1.text_input("Floor lead", s["lead"])
    shift = c2.selectbox("Shift", list(data.SHIFTS), index=list(data.SHIFTS).index(s["shift"]), disabled=locked,
                         help="Locked after attendance is confirmed.")
    s["shift"] = shift

    st.markdown("**Areas and standard crew size**")
    area_df = pd.DataFrame([{"Area": a["name"], "Standard crew": a["std"]} for a in s["areas"]])
    edited = st.data_editor(area_df, hide_index=True, disabled=["Area"], key="areas_editor", width="stretch",
                            column_config={"Standard crew": st.column_config.NumberColumn(min_value=0, step=1)})
    for a, std in zip(s["areas"], edited["Standard crew"]):
        a["std"] = None if pd.isna(std) else int(std)

    st.markdown("**Roster**")
    if locked:
        st.caption("Roster is locked after attendance is confirmed. Reset the demo to edit it.")
    area_names = {a["id"]: a["name"] for a in s["areas"]}
    name_to_id = {v: k for k, v in area_names.items()}
    roster_df = pd.DataFrame([{"Name": e["name"], "Role": e["role"], "Usual area": area_names.get(e["home"], "")}
                              for e in s["employees"]])
    roster = st.data_editor(
        roster_df, hide_index=True, num_rows="dynamic" if not locked else "fixed", disabled=locked,
        key="roster_editor", width="stretch",
        column_config={
            "Role": st.column_config.SelectboxColumn(options=list(data.ROLES), required=True),
            "Usual area": st.column_config.SelectboxColumn(options=list(area_names.values())),
        },
    )
    if not locked and st.button("Save roster"):
        new = []
        for i, r in roster.iterrows():
            if not isinstance(r["Name"], str) or not r["Name"].strip():
                continue
            new.append({"id": f"E{i + 1:03d}", "name": r["Name"].strip(),
                        "role": r["Role"] if r["Role"] in data.ROLES else "Operator",
                        "home": name_to_id.get(r["Usual area"], "L1")})
        s["employees"] = new
        s["assign"] = {e["id"]: BOX for e in new}
        s["selected"] = None
        st.success(f"Roster saved: {len(new)} employees, all back in the box.")

    st.divider()
    st.markdown("**Demo**")
    s["clock_mode"] = st.radio(
        "Clock", ["demo", "real"], index=["demo", "real"].index(s["clock_mode"]), horizontal=True,
        format_func=lambda v: "Demo clock (moves with the sidebar buttons)" if v == "demo" else "Real time",
    )
    if st.button("Reset demo", type="secondary"):
        store.reset()
        st.rerun()


# ---------- the window ----------

def page() -> None:
    st.markdown(CSS, unsafe_allow_html=True)
    s = store.get_state()

    with st.sidebar:
        st.markdown("**Floor Board demo**")
        st.caption("Memory only: refreshing the page resets the demo.")
        if s["clock_mode"] == "demo":
            st.markdown(f"Demo clock: **{store.fmt(store.now(s))}**")
            b1, b2 = st.columns(2)
            b1.button("+15 min", on_click=store.advance_clock, args=(s, 15), width="stretch")
            b2.button("+1 hour", on_click=store.advance_clock, args=(s, 60), width="stretch")
        else:
            st.markdown(f"Clock: **{store.fmt(store.now(s))}** (real time)")

    t1, t2, t3, t4 = st.tabs(["Floor Board", "Supervisor view", "End of shift", "Setup"])
    with t1:
        board(s)
    with t2:
        supervisor(s)
    with t3:
        summary(s)
    with t4:
        setup(s)
