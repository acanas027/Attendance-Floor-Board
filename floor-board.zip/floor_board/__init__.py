"""Floor Board: live crew tracking + start-of-shift attendance.

Standalone demo now; later this package is copied into the Schedule Board app
and `page()` is called from its own window/page.
"""

from .ui import page

__all__ = ["page"]
