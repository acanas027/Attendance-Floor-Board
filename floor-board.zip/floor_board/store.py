"""State and rules for the Floor Board.

Demo version: everything lives in st.session_state (memory only, resets on
refresh). When the app goes live, swap the bodies of `get_state` and the
`_save` hook for Google Sheets reads/writes; the UI does not change.
"""

from __future__ import annotations

import copy
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

import streamlit as st

from . import data

TZ = ZoneInfo("America/Chicago")
BOX = None  # an employee not on any area is "in the box"
STATE_KEY = "floor_board"


# ---------- setup ----------

def _fresh_state() -> dict:
    employees = [
        {"id": f"E{i:03d}", "name": n, "role": r, "home": h}
        for i, (n, r, h) in enumerate(data.EMPLOYEES, start=1)
    ]
    return {
        "employees": employees,
        "areas": copy.deepcopy(data.AREAS),
        "assign": {e["id"]: BOX for e in employees},
        "selected": None,
        "lead": "A. Rivera",
        "shift": "1st shift",
        "clock_mode": "demo",  # "demo" = clock moves only with the demo buttons; "real" = wall clock
        "demo_minutes": 0,
        "attendance_confirmed": False,
        "attendance_time": None,
        "attendance": {},  # eid -> {"status": Present|Absent|Late, "time": datetime}
        "left": {},  # eid -> datetime they were moved back to the box after attendance
        "open": {},  # eid -> (area_id, start)
        "intervals": [],  # {"eid", "area", "start", "end"}
        "events": [],  # {"t", "kind", "text"}
        "last_check": None,
        "checkins": 0,
        "ended": False,
        "end_time": None,
    }


def get_state() -> dict:
    if STATE_KEY not in st.session_state:
        st.session_state[STATE_KEY] = _fresh_state()
    return st.session_state[STATE_KEY]


def reset() -> None:
    st.session_state[STATE_KEY] = _fresh_state()


def _save(s: dict) -> None:
    """Live version: write changes to the backend here. Demo: nothing to do."""


# ---------- lookups ----------

def emp(s: dict, eid: str) -> dict:
    return next(e for e in s["employees"] if e["id"] == eid)


def area(s: dict, aid: str | None) -> dict | None:
    return next((a for a in s["areas"] if a["id"] == aid), None)


def area_short(s: dict, aid: str | None) -> str:
    return "Box" if aid is BOX else area(s, aid)["short"]


def crew(s: dict, aid: str | None) -> list[dict]:
    return [e for e in s["employees"] if s["assign"].get(e["id"]) == aid]


def is_line(a: dict) -> bool:
    return a["id"] != "BRK"


# ---------- clock ----------

def shift_start(s: dict) -> datetime:
    h, m = data.SHIFTS[s["shift"]]["start"]
    today = datetime.now(TZ).date()
    return datetime(today.year, today.month, today.day, h, m, tzinfo=TZ)


def now(s: dict) -> datetime:
    if s["clock_mode"] == "demo":
        return shift_start(s) + timedelta(minutes=s["demo_minutes"])
    return datetime.now(TZ)


def advance_clock(s: dict, minutes: int) -> None:
    s["demo_minutes"] += minutes


def fmt(t: datetime | None) -> str:
    if t is None:
        return ""
    return t.strftime("%I:%M %p").lstrip("0")


def fmt_min(m: float) -> str:
    m = int(round(m))
    return f"{m // 60}h {m % 60:02d}m"


# ---------- actions ----------

def _log(s: dict, kind: str, text: str) -> None:
    s["events"].insert(0, {"t": now(s), "kind": kind, "text": text})


def select(s: dict, eid: str) -> None:
    if s["ended"]:
        return
    s["selected"] = None if s["selected"] == eid else eid


def cancel_selection(s: dict) -> None:
    s["selected"] = None


def move_selected(s: dict, target: str | None) -> None:
    eid = s["selected"]
    s["selected"] = None
    if eid is None or s["ended"]:
        return
    prev = s["assign"][eid]
    if prev == target:
        return
    s["assign"][eid] = target

    if not s["attendance_confirmed"]:
        _save(s)
        return  # placing people before attendance is confirmed is not timed

    t = now(s)
    e = emp(s, eid)
    if eid in s["open"]:
        a, start = s["open"].pop(eid)
        s["intervals"].append({"eid": eid, "area": a, "start": start, "end": t})
    if target is not BOX:
        s["open"][eid] = (target, t)

    att = s["attendance"][eid]
    if prev is BOX and target is not BOX:
        if att["status"] == "Absent":
            att.update(status="Late", time=t)
            _log(s, "late", f"{e['name']} arrived late → {area_short(s, target)}")
        else:
            s["left"].pop(eid, None)
            _log(s, "move", f"{e['name']} back on the floor → {area_short(s, target)}")
    elif target is BOX:
        s["left"][eid] = t
        _log(s, "left", f"{e['name']} left the floor ({area_short(s, prev)} → Box)")
    else:
        _log(s, "move", f"{e['name']}  {area_short(s, prev)} → {area_short(s, target)}")
    _save(s)


def load_usual_layout(s: dict) -> None:
    if s["attendance_confirmed"]:
        return
    for e in s["employees"]:
        s["assign"][e["id"]] = e["home"]
    s["selected"] = None


def clear_board(s: dict) -> None:
    if s["attendance_confirmed"]:
        return
    for e in s["employees"]:
        s["assign"][e["id"]] = BOX
    s["selected"] = None


def confirm_attendance(s: dict) -> None:
    if s["attendance_confirmed"]:
        return
    t = now(s)
    present = absent = 0
    for e in s["employees"]:
        aid = s["assign"][e["id"]]
        if aid is BOX:
            s["attendance"][e["id"]] = {"status": "Absent", "time": t}
            absent += 1
        else:
            s["attendance"][e["id"]] = {"status": "Present", "time": t}
            s["open"][e["id"]] = (aid, t)
            present += 1
    s["attendance_confirmed"] = True
    s["attendance_time"] = t
    s["last_check"] = t
    s["selected"] = None
    _log(s, "attendance", f"Attendance confirmed by {s['lead']}: {present} present, {absent} absent")
    _save(s)


def confirm_board(s: dict) -> None:
    if not s["attendance_confirmed"] or s["ended"]:
        return
    t = now(s)
    on_time = check_minutes_left(s) >= 0
    s["last_check"] = t
    s["checkins"] += 1 if on_time else 0
    _log(s, "check", f"Board confirmed correct by {s['lead']}" + ("" if on_time else " (late)"))
    _save(s)


def end_shift(s: dict) -> None:
    if not s["attendance_confirmed"] or s["ended"]:
        return
    t = now(s)
    for eid, (a, start) in list(s["open"].items()):
        s["intervals"].append({"eid": eid, "area": a, "start": start, "end": t})
    s["open"].clear()
    s["ended"] = True
    s["end_time"] = t
    s["selected"] = None
    _log(s, "end", f"Shift ended by {s['lead']} · all times closed")
    _save(s)


# ---------- read models ----------

def check_minutes_left(s: dict) -> int:
    if not s["attendance_confirmed"] or s["last_check"] is None:
        return data.CHECK_EVERY_MIN
    due = s["last_check"] + timedelta(minutes=data.CHECK_EVERY_MIN)
    return int((due - now(s)).total_seconds() // 60)


def minutes_by_area(s: dict, eid: str) -> dict[str, float]:
    out: dict[str, float] = {}
    for iv in s["intervals"]:
        if iv["eid"] == eid:
            out[iv["area"]] = out.get(iv["area"], 0) + (iv["end"] - iv["start"]).total_seconds() / 60
    if eid in s["open"]:
        a, start = s["open"][eid]
        out[a] = out.get(a, 0) + max(0.0, (now(s) - start).total_seconds() / 60)
    return out


def summary_rows(s: dict) -> list[dict]:
    rows = []
    for e in s["employees"]:
        att = s["attendance"].get(e["id"], {})
        status = att.get("status", "Not confirmed")
        if status == "Late":
            status = f"Late ({fmt(att['time'])})"
        if e["id"] in s["left"]:
            status += f" · left {fmt(s['left'][e['id']])}"
        mins = minutes_by_area(s, e["id"])
        brk = mins.pop("BRK", 0)
        rows.append({
            "eid": e["id"],
            "Employee": e["name"],
            "Role": e["role"],
            "Attendance": status,
            "areas": mins,
            "Time by area": " · ".join(f"{area_short(s, a)} {fmt_min(m)}" for a, m in mins.items() if m >= 1),
            "Break": fmt_min(brk) if brk >= 1 else "",
            "Worked": fmt_min(sum(mins.values())),
            "worked_min": round(sum(mins.values())),
        })
    return rows


def short_areas(s: dict) -> list[tuple[dict, int]]:
    out = []
    for a in s["areas"]:
        if a["std"] is None:
            continue
        n = len(crew(s, a["id"]))
        if n < a["std"]:
            out.append((a, n))
    return out
