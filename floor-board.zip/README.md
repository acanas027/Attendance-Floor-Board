# Floor Board (demo)

Live crew board for floor leads: start-of-shift attendance, tap-to-move crew tracking, supervisor view and end-of-shift minutes by area. Demo version: sample names, memory only (a page refresh resets it).

## Run

```bash
pip install -r requirements.txt
streamlit run app.py
```

## How it works

1. **Start of shift:** everyone starts in the box. Tap **Load usual layout** (or place people one by one: tap a name, then tap **Move to …** on a line). Send anyone who isn't here back to the box.
2. **Confirm attendance:** people on a line = present, people left in the box = absent. Line time starts now.
3. **During the shift:** tap a name, tap the area they're going to. Every move is timed. Someone placed from the box after attendance = late. Someone sent to the box = left the floor. **Break** pauses line time.
4. **Board check:** every 2 hours the lead taps **Board is correct**.
5. **End of shift:** closes everyone's time; download minutes by area, attendance and the move log as CSV.

The sidebar has a demo clock (+15 min / +1 hour) so a whole shift can be shown in a few minutes. Switch to real time in Setup.

## Files

```
app.py                 entry point for the standalone demo
floor_board/
  __init__.py          exposes page()
  ui.py                the window and its 4 sub-windows: Floor Board, Supervisor view, End of shift, Setup
  store.py             state + rules (attendance, moves, timing, summaries); the only file that touches storage
  data.py              sample roster, areas, shifts
.streamlit/config.toml dark theme for the demo
```

## Moving it into the Schedule Board app

1. Copy the `floor_board/` folder into the Schedule Board repo.
2. Add a page that calls it:
   ```python
   from floor_board import page
   page()
   ```
3. Replace the memory storage in `store.py` (`get_state` and `_save`) with Google Sheets reads/writes, and load the roster/areas from the sheet instead of `data.py`. The screens don't change.
4. For the live supervisor view across devices, wrap `supervisor()` in `st.fragment(run_every="5s")` once the data is shared.
